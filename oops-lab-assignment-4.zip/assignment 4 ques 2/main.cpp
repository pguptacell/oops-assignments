#include <iostream>
using namespace std;

class Rectangle
{
    int l, b;
public:
    Rectangle(int x = 0, int y = 0)
    {
        l = x;
        b = y;
    }
    int area()
    {
        return l * b;
    }

    ~Rectangle()
    {
        cout << "Destructor called\n";
    }
};
int main()
{
    Rectangle r[3] = {Rectangle(), Rectangle(5), Rectangle(4,6)};

    for(int i=0;i<3;i++)
    {
        cout << "Area " << i+1 << ": " << r[i].area() << endl;
    }

    return 0;
}

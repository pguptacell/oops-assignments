#include <iostream>
using namespace std;

class Demo
{
public:
    Demo()
    {
        cout << "Object Created\n";
    }

    ~Demo()
    {
        cout << "Object Deleted\n";
    }
};

int main()
{
    int *a = new int(10);
    float *b = new float(5.5);

    cout << *a << endl;
    cout << *b << endl;

    int *arr = new int[3]{1,2,3};
    float *farr = new float[2]{4.4,5.5};

    Demo *obj = new Demo;
    Demo *objArr = new Demo[2];

    delete a;
    delete b;
    delete[] arr;
    delete[] farr;
    delete obj;
    delete[] objArr;

    return 0;
}

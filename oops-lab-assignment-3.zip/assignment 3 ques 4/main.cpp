#include <iostream>
using namespace std;
class B;
class A {
    int x;
public:
    A() {
        x = 10;
    }
    friend class B;
};
class B {
public:
    void show(A a) {
        cout << "Value of x = " << a.x << endl;
    }
};
int main() {
    A objA;
    B objB;
    objB.show(objA);
    return 0;
}

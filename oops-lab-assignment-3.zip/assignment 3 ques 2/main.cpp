#include <iostream>
using namespace std;
class B;   // forward declaration
class A {
    int x;
public:
    A(int a) {
        x = a;
    }
    friend void swap(A &, B &);
};
class B {
    int y;
public:
    B(int b) {
        y = b;
    }
    friend void swap(A &, B &);
};
void swap(A &a, B &b) {
    int temp = a.x;
    a.x = b.y;
    b.y = temp;
    cout << "After swapping:" << endl;
    cout << "A = " << a.x << endl;
    cout << "B = " << b.y << endl;
}
int main() {
    A obj1(5);
    B obj2(10);
    swap(obj1, obj2);
    return 0;
}

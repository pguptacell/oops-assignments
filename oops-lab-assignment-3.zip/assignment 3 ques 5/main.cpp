#include <iostream>
using namespace std;
class Rectangle {
    int length, breadth;
public:
    void set() {
        cin >> length >> breadth;
    }

    void area() {
        cout << "Area = " << length * breadth << endl;
    }
};
int main() {
    Rectangle r[3];
    for(int i = 0; i < 3; i++) {
        cout << "Enter length and breadth: ";
        r[i].set();
    }
    for(int i = 0; i < 3; i++) {
        r[i].area();
    }
    return 0;
}

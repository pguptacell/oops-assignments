#include <iostream>
using namespace std;

class Student {
public:
    int roll;
     void set(int roll) {
        this->roll = roll;   // this pointer
    }
    void show() {
        cout << "Roll number: " << roll << endl;
    }
};
int main() {
    Student s;        // object
    Student *p;       // pointer to object
    p = &s;
    s.set(10);        // dot operator
    p->show();        // arrow operator
    return 0;
}

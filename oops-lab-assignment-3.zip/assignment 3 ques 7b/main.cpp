#include <iostream>
using namespace std;
class Test {
public:
    int x;

    Test(int a) {
        x = a;
    }
};
Test modify(Test &t) {
    t.x = t.x + 10;
    return t;
}
int main() {
    Test obj(5);
    Test obj2 = modify(obj);
    cout << "After modification: " << obj.x << endl;
    return 0;
}

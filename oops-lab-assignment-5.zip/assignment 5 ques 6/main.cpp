#include <iostream>
using namespace std;

class Book {
public:
    string title, author;
    float price;
};

class Textbook : public Book {
public:
    string subject;
};

int main() {
    Textbook t;
    t.title = "C++";
    t.author = "Bjarne";
    t.price = 500;
    t.subject = "Programming";

    cout<<t.title<<"\n"<<t.author<<"\n"<<t.price<<"\n"<<t.subject;
}

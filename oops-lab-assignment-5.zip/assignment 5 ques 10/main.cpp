#include <iostream>
using namespace std;

class Person {
public:
    string name;
};

class Staff : public Person {
public:
    int emp_id;
};

class Student : public Person {
public:
    int roll;
};

class TeachingAssistant : public Staff, public Student {
};

int main() {
    TeachingAssistant t;
}

#include <iostream>
using namespace std;

class Speedometer {
public:
    int speed = 80;
};

class FuelGauge {
public:
    int fuel = 50;
};

class Thermometer {
public:
    int temp = 35;
};

class CarDashboard : public Speedometer, public FuelGauge, public Thermometer {
public:
    void display() {
        cout<<"Speed: "<<speed<<"\nFuel: "<<fuel<<"\nTemp: "<<temp;
    }
};

int main() {
    CarDashboard c;
    c.display();
}

#include <iostream>
using namespace std;

class LibraryUser {
public:
    string name;
};

class Student : public LibraryUser {
public:
    int grade;
};

class Teacher : public LibraryUser {
public:
    string dept;
};

#include <iostream>
using namespace std;
class Base {
public:
    int a = 10;

protected:
    int b = 20;

private:
    int c = 30;
};
// PUBLIC inheritance
class DerivedPublic : public Base {
public:
    void show() {
        cout << "Public Inheritance\n";
        cout << "a = " << a << endl;
        cout << "b = " << b << endl;
        // c not accessible
    }
};
// PROTECTED inheritance
class DerivedProtected : protected Base {
public:
    void show() {
        cout << "\nProtected Inheritance\n";
        cout << "a = " << a << endl;
        cout << "b = " << b << endl;
    }
};
// PRIVATE inheritance
class DerivedPrivate : private Base {
public:
    void show() {
        cout << "\nPrivate Inheritance\n";
        cout << "a = " << a << endl;
        cout << "b = " << b << endl;
    }
};
int main() {
    DerivedPublic dp;
    dp.show();
    DerivedProtected dpro;
    dpro.show();
    DerivedPrivate dpri;
    dpri.show();
    return 0;
}

#include <iostream>
using namespace std;

class Vehicle {
public:
    string model;
};

class Truck : public Vehicle {
public:
    int load;
};

class RefrigeratedTruck : public Truck {
public:
    int temp;
};

int main() {
    RefrigeratedTruck r;
    r.model="TATA";
    r.load=1000;
    r.temp=5;

    cout<<r.model<<" "<<r.load<<" "<<r.temp;
}
